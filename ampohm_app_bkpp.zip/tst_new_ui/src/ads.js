// =====================================================================
// AD UNIT IDS
// -----------------------------------------------------------------
// These are Google's official AdMob TEST ad unit IDs (from the
// `TestIds` export of react-native-google-mobile-ads). They always
// serve a clearly-labelled "Test Ad" and never earn real revenue —
// safe to leave wired up while you build/test.
//
// BEFORE PUBLISHING: replace the two lines below with your real ad
// unit IDs from the AdMob console (Apps > your app > Ad units), and
// update the androidAppId/iosAppId in app.json too. Do NOT click your
// own real ads while testing — that risks your AdMob account.
// =====================================================================
import { TestIds } from "react-native-google-mobile-ads";

export const AD_UNIT_IDS = {
  banner: TestIds.BANNER,
  rewarded: TestIds.REWARDED,
};
