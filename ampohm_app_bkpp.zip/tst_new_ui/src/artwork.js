// =====================================================================
// ARTWORK — original line-art illustrations built with react-native-svg.
// Mirrors the CARD_ART / FIELD_ICON objects from the web preview
// (ampohm_preview.html) so both builds stay visually in sync. These are
// hand-drawn shapes, not photos — safe to ship, no licensing concerns.
// =====================================================================
import React from "react";
import { View, Image, StyleSheet } from "react-native";
import Svg, {
  Circle,
  Ellipse,
  Rect,
  Path,
  Line,
  Defs,
  RadialGradient,
  LinearGradient,
  Stop,
} from "react-native-svg";

// ---------------------------------------------------------------------
// CardPhoto — real (AI-generated, licensed for use in this app) product
// photos for each home-screen tool card. require() paths must be
// static, hence the explicit map below rather than a template string.
// Renders bottom-right within the card, above CardArt/gradient, below
// the icon/title/sub text.
// ---------------------------------------------------------------------
const CARD_PHOTOS = {
  ohm: require("../assets/cards/ohm.png"),
  amp: require("../assets/cards/amp.png"),
  top: require("../assets/cards/top.png"),
  cable: require("../assets/cards/cable.png"),
  dmx: require("../assets/cards/dmx.png"),
};

export function CardPhoto({ type, opacity = 0.9, style }) {
  const source = CARD_PHOTOS[type];
  if (!source) return null;
  return (
    <Image
      pointerEvents="none"
      source={source}
      resizeMode="contain"
      style={[photoStyles.photo, { opacity }, style]}
    />
  );
}

const photoStyles = StyleSheet.create({
  photo: {
    position: "absolute",
    right: -8,
    bottom: -8,
    width: "72%",
    height: "88%",
  },
});

// ---------------------------------------------------------------------
// CardArt — full-card background illustration for each home-screen
// tool card. Render this as the FIRST child inside the card, sized to
// fill it (e.g. StyleSheet.absoluteFill), then put the icon/title/sub
// text on top. Caller controls opacity via the `opacity` prop — the
// app uses 0.3 (30%) so text stays readable over the blue card.
// ---------------------------------------------------------------------
export function CardArt({ type, opacity = 0.3, style }) {
  return (
    <View pointerEvents="none" style={[styles.fill, style, { opacity }]}>
      <Svg width="100%" height="100%" viewBox="0 0 200 200" preserveAspectRatio="xMidYMid meet">
        {type === "ohm" && <OhmArt />}
        {type === "amp" && <AmpArt />}
        {type === "top" && <TopArt />}
        {type === "cable" && <CableArt />}
        {type === "dmx" && <DmxArt />}
      </Svg>
    </View>
  );
}

// Bare speaker driver — tilted 3/4 view: basket rim, corrugated cone,
// dust cap with a soft highlight, mounting screws.
function OhmArt() {
  return (
    <>
      <Defs>
        <RadialGradient id="ohmCone" cx="34%" cy="28%" r="82%">
          <Stop offset="0%" stopColor="#ffffff" stopOpacity="0.95" />
          <Stop offset="45%" stopColor="#dbe8fd" stopOpacity="0.55" />
          <Stop offset="100%" stopColor="#1d4ed8" stopOpacity="0.14" />
        </RadialGradient>
        <RadialGradient id="ohmCap" cx="30%" cy="26%" r="78%">
          <Stop offset="0%" stopColor="#ffffff" stopOpacity="0.98" />
          <Stop offset="55%" stopColor="#eef4ff" stopOpacity="0.65" />
          <Stop offset="100%" stopColor="#1d4ed8" stopOpacity="0.3" />
        </RadialGradient>
      </Defs>
      <Ellipse cx="100" cy="102" rx="95" ry="84" stroke="#ffffff" strokeOpacity="0.35" strokeWidth="4" />
      <Ellipse cx="100" cy="102" rx="82" ry="72" fill="url(#ohmCone)" stroke="#ffffff" strokeOpacity="0.45" strokeWidth="1.5" />
      {[68, 60, 52, 44, 36].map((r, i) => (
        <Ellipse key={r} cx="100" cy="102" rx={r} ry={r * 0.88} stroke="#ffffff" strokeOpacity={0.28 - i * 0.03} strokeWidth="1" />
      ))}
      <Ellipse cx="100" cy="102" rx="30" ry="27" fill="url(#ohmCap)" stroke="#ffffff" strokeOpacity="0.55" strokeWidth="1.5" />
      <Ellipse cx="90" cy="93" rx="10" ry="6" fill="#ffffff" fillOpacity="0.5" />
      {[15, 55, 95, 135, 175, 215, 255, 295, 335].map((a) => {
        const rad = (a * Math.PI) / 180;
        const x = 100 + 90 * Math.cos(rad);
        const y = 102 + 80 * Math.sin(rad);
        return <Circle key={a} cx={x} cy={y} r="3" fill="#ffffff" fillOpacity="0.45" />;
      })}
    </>
  );
}

// Rack-mount power amplifier — chassis, mesh vents, a small status
// screen with level bars, gain knob, handles.
function AmpArt() {
  return (
    <>
      <Defs>
        <LinearGradient id="ampBody" x1="0" y1="0" x2="0" y2="1">
          <Stop offset="0%" stopColor="#ffffff" stopOpacity="0.22" />
          <Stop offset="55%" stopColor="#ffffff" stopOpacity="0.08" />
          <Stop offset="100%" stopColor="#ffffff" stopOpacity="0.16" />
        </LinearGradient>
        <LinearGradient id="ampScreen" x1="0" y1="0" x2="0" y2="1">
          <Stop offset="0%" stopColor="#dbeafe" stopOpacity="0.7" />
          <Stop offset="100%" stopColor="#93c5fd" stopOpacity="0.35" />
        </LinearGradient>
      </Defs>
      <Rect x="4" y="30" width="10" height="130" rx="3" fill="#ffffff" fillOpacity="0.28" transform="scale(1,0.87) translate(0,20)" />
      <Rect x="16" y="40" width="168" height="112" rx="10" fill="url(#ampBody)" stroke="#ffffff" strokeOpacity="0.48" strokeWidth="2.5" />
      {Array.from({ length: 5 }).map((_, r) =>
        Array.from({ length: 8 }).map((_, c) => (
          <Circle key={`${r}-${c}`} cx={30 + c * 7} cy={54 + r * 11} r="2" fill="#ffffff" fillOpacity="0.22" />
        ))
      )}
      <Rect x="106" y="56" width="60" height="40" rx="4" fill="url(#ampScreen)" stroke="#ffffff" strokeOpacity="0.5" strokeWidth="1.5" />
      {[0, 1, 2, 3, 4, 5].map((i) => (
        <Rect key={i} x={112 + i * 8} y={82 - ((i % 4) + 2) * 5} width="4" height={((i % 4) + 2) * 5} fill="#ffffff" fillOpacity="0.55" />
      ))}
      <Circle cx="140" cy="130" r="14" stroke="#ffffff" strokeOpacity="0.55" strokeWidth="2.5" />
      <Circle cx="140" cy="130" r="3" fill="#ffffff" fillOpacity="0.65" />
      <Circle cx="30" cy="130" r="6" stroke="#93c5fd" strokeOpacity="0.85" strokeWidth="2" fill="none" />
      <Circle cx="30" cy="130" r="2" fill="#93c5fd" fillOpacity="0.9" />
      <Rect x="24" y="144" width="46" height="5" rx="2.5" fill="#ffffff" fillOpacity="0.35" />
    </>
  );
}

// Dual top cabinets — horn-loaded HF with shading, LF cone with a
// highlight, mesh-dot grille, rounded cabinet edges.
function TopArt() {
  const Cab = ({ dx }) => (
    <>
      <Rect x={10 + dx} y="14" width="86" height="172" rx="11" fill="#ffffff" fillOpacity="0.14" stroke="#ffffff" strokeOpacity="0.5" strokeWidth="2.5" />
      <Path
        d={`M${33 + dx} 38 L${73 + dx} 38 L${60 + dx} 68 L${46 + dx} 68 Z`}
        fill="#ffffff"
        fillOpacity="0.42"
        stroke="#ffffff"
        strokeOpacity="0.55"
        strokeWidth="1.5"
      />
      <Circle cx={53 + dx} cy="132" r="32" fill="url(#topCone)" stroke="#ffffff" strokeOpacity="0.55" strokeWidth="2" />
      <Circle cx={53 + dx} cy="132" r="24" stroke="#ffffff" strokeOpacity="0.3" strokeWidth="1" />
      <Circle cx={53 + dx} cy="132" r="16" stroke="#ffffff" strokeOpacity="0.35" strokeWidth="1.5" />
      <Circle cx={53 + dx} cy="132" r="6.5" fill="#ffffff" fillOpacity="0.55" />
    </>
  );
  return (
    <>
      <Defs>
        <RadialGradient id="topCone" cx="35%" cy="30%" r="80%">
          <Stop offset="0%" stopColor="#ffffff" stopOpacity="0.85" />
          <Stop offset="60%" stopColor="#dbe8fd" stopOpacity="0.4" />
          <Stop offset="100%" stopColor="#1d4ed8" stopOpacity="0.12" />
        </RadialGradient>
      </Defs>
      <Cab dx={0} />
      <Cab dx={98} />
    </>
  );
}

// Coiled speaker cable with a metallic XLR-style connector — tapered
// windings, connector pins and highlight.
function CableArt() {
  return (
    <>
      <Defs>
        <LinearGradient id="cableConn" x1="0" y1="0" x2="1" y2="1">
          <Stop offset="0%" stopColor="#ffffff" stopOpacity="0.55" />
          <Stop offset="100%" stopColor="#ffffff" stopOpacity="0.12" />
        </LinearGradient>
      </Defs>
      {Array.from({ length: 7 }).map((_, i) => {
        const r = 22 + i * 10;
        return (
          <Circle
            key={i}
            cx="148"
            cy="98"
            r={r}
            stroke="#ffffff"
            strokeOpacity={0.5 - i * 0.055}
            strokeWidth={3.4 - i * 0.25}
            strokeDasharray={`${(r * 5.5).toFixed(0)} 999`}
            strokeLinecap="round"
            fill="none"
          />
        );
      })}
      <Circle cx="148" cy="98" r="12" fill="#ffffff" fillOpacity="0.5" />
      <Path d="M18 172 Q 42 120 18 66" stroke="#ffffff" strokeOpacity="0.55" strokeWidth="7" fill="none" strokeLinecap="round" />
      <Circle cx="18" cy="56" r="18" fill="url(#cableConn)" stroke="#ffffff" strokeOpacity="0.6" strokeWidth="2.5" />
      <Circle cx="14" cy="49" r="4" fill="#ffffff" fillOpacity="0.55" />
      <Circle cx="11" cy="51" r="2.3" fill="#ffffff" fillOpacity="0.75" />
      <Circle cx="25" cy="51" r="2.3" fill="#ffffff" fillOpacity="0.75" />
      <Circle cx="18" cy="63" r="2.3" fill="#ffffff" fillOpacity="0.75" />
    </>
  );
}

// Moving-head fixture — metallic yoke, head housing, a glowing lens
// with a soft beam cone, base control panel.
function DmxArt() {
  return (
    <>
      <Defs>
        <RadialGradient id="dmxLens" cx="38%" cy="32%" r="75%">
          <Stop offset="0%" stopColor="#ffffff" stopOpacity="0.98" />
          <Stop offset="45%" stopColor="#bfdbfe" stopOpacity="0.7" />
          <Stop offset="100%" stopColor="#1d4ed8" stopOpacity="0.25" />
        </RadialGradient>
        <RadialGradient id="dmxBeam" cx="50%" cy="50%" r="50%">
          <Stop offset="0%" stopColor="#bfdbfe" stopOpacity="0.35" />
          <Stop offset="100%" stopColor="#bfdbfe" stopOpacity="0" />
        </RadialGradient>
      </Defs>
      <Circle cx="100" cy="72" r="60" fill="url(#dmxBeam)" />
      <Rect x="68" y="166" width="64" height="16" rx="6" fill="#ffffff" fillOpacity="0.32" />
      <Circle cx="82" cy="174" r="2" fill="#93c5fd" fillOpacity="0.9" />
      <Circle cx="92" cy="174" r="2" fill="#ffffff" fillOpacity="0.5" />
      <Path d="M53 166 V 88 Q 53 74 67 74 H 84" stroke="#ffffff" strokeOpacity="0.55" strokeWidth="8" fill="none" strokeLinecap="round" />
      <Path d="M147 166 V 88 Q 147 74 133 74 H 116" stroke="#ffffff" strokeOpacity="0.4" strokeWidth="8" fill="none" strokeLinecap="round" />
      <Rect x="68" y="42" width="64" height="54" rx="18" fill="#ffffff" fillOpacity="0.16" stroke="#ffffff" strokeOpacity="0.55" strokeWidth="2.5" />
      <Circle cx="100" cy="70" r="19" fill="url(#dmxLens)" stroke="#ffffff" strokeOpacity="0.65" strokeWidth="2" />
      <Circle cx="93" cy="62" r="5" fill="#ffffff" fillOpacity="0.8" />
      <Circle cx="100" cy="70" r="32" stroke="#ffffff" strokeOpacity="0.18" strokeWidth="1.5" />
      <Rect x="75" y="100" width="16" height="8" rx="2" fill="#ffffff" fillOpacity="0.3" />
    </>
  );
}

// ---------------------------------------------------------------------
// FieldIcon — small mono-tone icon shown next to a calculator's field
// label. Same visual language as CardArt, just tiny + single-color so
// it sits quietly next to input labels instead of competing.
// type: "lfSpeaker" | "hfDriver" | "power" | "impedance" | "qty" |
//       "length" | "channels" | "fixtures" | "address" | "connection"
// ---------------------------------------------------------------------
export function FieldIcon({ type, size = 26, color = "#2563eb" }) {
  return (
    <View style={[styles.fieldIconBox, { width: size, height: size, borderRadius: size * 0.3 }]}>
      <Svg width={size * 0.58} height={size * 0.58} viewBox="0 0 24 24" fill="none">
        {type === "lfSpeaker" && (
          <>
            <Circle cx="12" cy="12" r="9" stroke={color} strokeWidth="1.6" />
            <Circle cx="12" cy="12" r="5.2" stroke={color} strokeWidth="1.4" />
            <Circle cx="12" cy="12" r="1.8" fill={color} />
          </>
        )}
        {type === "hfDriver" && (
          <>
            <Path d="M5 9 L13 9 L18 5 V19 L13 15 L5 15 Z" stroke={color} strokeWidth="1.5" strokeLinejoin="round" />
            <Path d="M20 9 Q22 12 20 15" stroke={color} strokeWidth="1.5" strokeLinecap="round" />
          </>
        )}
        {type === "power" && <Path d="M13 3 L5 14 H11 L10 21 L19 9 H13 Z" fill={color} fillOpacity="0.85" />}
        {type === "impedance" && (
          <>
            <Path d="M6 12a6 6 0 1 1 12 0" stroke={color} strokeWidth="1.8" strokeLinecap="round" />
            <Line x1="4" y1="19" x2="9" y2="19" stroke={color} strokeWidth="1.8" strokeLinecap="round" />
            <Line x1="15" y1="19" x2="20" y2="19" stroke={color} strokeWidth="1.8" strokeLinecap="round" />
          </>
        )}
        {type === "qty" && (
          <>
            <Rect x="4" y="4" width="7" height="7" rx="1.5" stroke={color} strokeWidth="1.5" />
            <Rect x="13" y="4" width="7" height="7" rx="1.5" stroke={color} strokeWidth="1.5" opacity="0.55" />
            <Rect x="4" y="13" width="7" height="7" rx="1.5" stroke={color} strokeWidth="1.5" opacity="0.55" />
            <Rect x="13" y="13" width="7" height="7" rx="1.5" stroke={color} strokeWidth="1.5" opacity="0.3" />
          </>
        )}
        {type === "length" && (
          <Path d="M3 12h18M3 12v4M8 12v3M13 12v4M18 12v3" stroke={color} strokeWidth="1.6" strokeLinecap="round" />
        )}
        {type === "channels" && (
          <>
            <Line x1="6" y1="4" x2="6" y2="20" stroke={color} strokeWidth="1.6" strokeLinecap="round" />
            <Circle cx="6" cy="9" r="2" fill={color} />
            <Line x1="12" y1="4" x2="12" y2="20" stroke={color} strokeWidth="1.6" strokeLinecap="round" />
            <Circle cx="12" cy="15" r="2" fill={color} />
            <Line x1="18" y1="4" x2="18" y2="20" stroke={color} strokeWidth="1.6" strokeLinecap="round" />
            <Circle cx="18" cy="11" r="2" fill={color} />
          </>
        )}
        {type === "fixtures" && (
          <>
            <Rect x="8" y="4" width="8" height="7" rx="2.5" stroke={color} strokeWidth="1.6" />
            <Circle cx="12" cy="7.5" r="2" fill={color} fillOpacity="0.6" />
            <Path d="M6 20 V16 Q6 13 9 13 H15 Q18 13 18 16 V20" stroke={color} strokeWidth="1.6" strokeLinecap="round" />
          </>
        )}
        {type === "address" && (
          <>
            <Rect x="4" y="6" width="16" height="12" rx="2.5" stroke={color} strokeWidth="1.6" />
            <Line x1="8" y1="10" x2="16" y2="10" stroke={color} strokeWidth="1.4" strokeLinecap="round" />
            <Line x1="8" y1="14" x2="12" y2="14" stroke={color} strokeWidth="1.4" strokeLinecap="round" />
          </>
        )}
        {type === "connection" && (
          <>
            <Circle cx="6" cy="12" r="3" stroke={color} strokeWidth="1.6" />
            <Circle cx="18" cy="12" r="3" stroke={color} strokeWidth="1.6" />
            <Line x1="9" y1="12" x2="15" y2="12" stroke={color} strokeWidth="1.6" />
          </>
        )}
        {type === "material" && (
          <>
            <Circle cx="12" cy="12" r="8" stroke={color} strokeWidth="1.6" />
            <Path d="M6 9c3 2 9 2 12 0M6 15c3 -2 9 -2 12 0" stroke={color} strokeWidth="1.4" strokeLinecap="round" fill="none" />
          </>
        )}
      </Svg>
    </View>
  );
}

// ---------------------------------------------------------------------
// EqualizerArt — low-opacity frequency-bar illustration behind the
// home screen's "AmpOhm" wordmark. Purely decorative.
// ---------------------------------------------------------------------
const EQ_HEIGHTS = [14, 22, 34, 48, 60, 74, 86, 94, 86, 74, 60, 48, 60, 74, 86, 94, 86, 74, 60, 48, 34, 22, 14];
export function EqualizerArt({ opacity = 0.16, style }) {
  const barW = 8;
  const gap = 4;
  const step = barW + gap;
  const totalW = EQ_HEIGHTS.length * step - gap;
  const startX = (300 - totalW) / 2;
  const baseline = 108;
  return (
    <View pointerEvents="none" style={[styles.eqWrap, style, { opacity }]}>
      <Svg width="100%" height="100%" viewBox="0 0 300 120" preserveAspectRatio="xMidYMid meet">
        <Defs>
          <LinearGradient id="eq" x1="0" y1="1" x2="0" y2="0">
            <Stop offset="0%" stopColor="#1d4ed8" />
            <Stop offset="100%" stopColor="#93c5fd" />
          </LinearGradient>
        </Defs>
        {EQ_HEIGHTS.map((h, i) => (
          <Rect key={i} x={startX + i * step} y={baseline - h} width={barW} height={h} rx={4} fill="url(#eq)" />
        ))}
      </Svg>
    </View>
  );
}

const styles = StyleSheet.create({
  fill: { position: "absolute", top: 0, left: 0, right: 0, bottom: 0 },
  fieldIconBox: {
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(37,99,235,0.08)",
    borderWidth: 1,
    borderColor: "rgba(37,99,235,0.16)",
  },
  eqWrap: { width: 260, height: 110, alignSelf: "center" },
});
