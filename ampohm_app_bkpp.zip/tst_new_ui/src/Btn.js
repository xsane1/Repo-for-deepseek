// =====================================================================
// Btn — drop-in replacement for TouchableOpacity that adds a subtle,
// premium press animation (scale + slight settle) instead of the
// default opacity flash. Same API: style / onPress / children / etc.
// Used everywhere TouchableOpacity was used in App.js.
// =====================================================================
import React, { useRef } from "react";
import { Animated, Pressable } from "react-native";

export default function Btn({ style, onPress, children, disabled, ...rest }) {
  const scale = useRef(new Animated.Value(1)).current;

  const pressIn = () => {
    Animated.spring(scale, {
      toValue: 0.96,
      useNativeDriver: true,
      speed: 40,
      bounciness: 4,
    }).start();
  };
  const pressOut = () => {
    Animated.spring(scale, {
      toValue: 1,
      useNativeDriver: true,
      speed: 18,
      bounciness: 9,
    }).start();
  };

  return (
    <Pressable onPress={onPress} onPressIn={pressIn} onPressOut={pressOut} disabled={disabled} {...rest}>
      <Animated.View style={[style, { transform: [{ scale }] }]}>{children}</Animated.View>
    </Pressable>
  );
}
