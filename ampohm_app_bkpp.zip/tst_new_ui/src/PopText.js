// =====================================================================
// PopText — a Text that plays a subtle "pop in" (scale + fade) each
// time its displayed value changes. Used for result numbers (Ohm
// load, Amp W ranges, DMX addresses, stepper counts) so they feel
// alive without being distracting.
// =====================================================================
import React, { useEffect, useRef } from "react";
import { Animated } from "react-native";

export default function PopText({ value, style, children }) {
  const anim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    anim.setValue(0);
    Animated.spring(anim, {
      toValue: 1,
      useNativeDriver: true,
      speed: 22,
      bounciness: 10,
    }).start();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);

  const scale = anim.interpolate({ inputRange: [0, 1], outputRange: [0.82, 1] });

  return (
    <Animated.Text style={[style, { opacity: anim, transform: [{ scale }] }]}>
      {children}
    </Animated.Text>
  );
}
